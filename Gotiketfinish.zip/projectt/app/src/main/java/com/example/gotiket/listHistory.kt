package com.example.gotiket

class listHistory (
    val idtiket: String,
    val iduser:String,
    val jenis:String,
    val harga:String,
    val jumlah: String,
    val status:String,
    val tglberangkat:String,
)