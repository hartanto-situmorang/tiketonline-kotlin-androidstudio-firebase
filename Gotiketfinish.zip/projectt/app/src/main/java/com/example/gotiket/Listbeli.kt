package com.example.gotiket

data class Listbeli(
    val idtiket: String,
    val iduser:String,
    val jenis: String,
    val jumlah: String,
    val komentar:String,
    val status:String,
    val tglberangkat:String,
)
