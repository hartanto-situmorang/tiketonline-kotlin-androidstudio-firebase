package com.example.gotiket

data class user (
    val id:String,
    val email: String,
    val nama: String,
    val notelp : String,
    val password:String
)