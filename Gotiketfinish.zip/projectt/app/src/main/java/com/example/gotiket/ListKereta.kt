package com.example.gotiket

data class ListKereta(
    var harga: String,
    var id:String,
    var jam: String,
    var jemput:String,
    var jenis: String,
    var namatiket:String,
    var tgl: String,
    var tujuan:String
)
